import React, { useState } from 'react';
import { User, Mail, Phone, MapPin, Github, Linkedin, ExternalLink, Code, Briefcase, GraduationCap, Award, Download } from 'lucide-react';

function App() {
  const [activeSection, setActiveSection] = useState('about');

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/20 backdrop-blur-lg border-b border-white/10 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="text-2xl font-bold text-white">Rafael Franco</div>
            <div className="hidden md:flex space-x-8">
              {['about', 'skills', 'projects', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`capitalize transition-colors duration-300 ${
                    activeSection === section
                      ? 'text-purple-400'
                      : 'text-white hover:text-purple-300'
                  }`}
                >
                  {section === 'about' ? 'Início' : 
                   section === 'skills' ? 'Habilidades' : 
                   section === 'projects' ? 'Projetos' : 'Contato'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="about" className="pt-20 pb-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            {/* Profile Image */}
            <div className="relative">
              <div className="w-80 h-80 rounded-full overflow-hidden border-4 border-purple-400/30 shadow-2xl">
                <img
                  src="/foto rafael.jpg"
                  alt="Rafael Américo Franco de Azevedo - Foto de Perfil"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-purple-400/20 to-transparent"></div>
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center lg:text-left">
              <p className="text-purple-400 font-semibold mb-4 text-lg">OLÁ, MEU NOME É</p>
              <h1 className="text-4xl lg:text-6xl font-bold text-white mb-6">
                Rafael Américo Franco
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">
                  de Azevedo
                </span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Desenvolvedor back-end em formação em busca da primeira oportunidade na área. 
                Disponível para trabalho Presencial, Híbrido e remoto e pronto para contribuir 
                com soluções modernas e inteligentes. Se está na procura de alguém criativo e 
                com sede de evoluir vamos conversar!
              </p>
              <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105"
                >
                  Entre em Contato
                </button>
                <button className="border-2 border-purple-400 text-purple-400 px-8 py-3 rounded-full font-semibold hover:bg-purple-400 hover:text-white transition-all duration-300 flex items-center gap-2">
                  <Download size={18} />
                  Baixar Currículo
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 px-6 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">Sobre Mim</h2>
            <p className="text-xl text-purple-400">Desenvolvedor Back-end</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-gray-300 leading-relaxed text-lg">
                Sou um estudante dedicado, finalizando minha graduação em Análise e Desenvolvimento 
                de Sistemas, apaixonado por tecnologia e desenvolvimento de software. Busco constantemente 
                aprimorar minhas habilidades e conhecimentos para criar soluções inovadoras.
              </p>
              <p className="text-gray-300 leading-relaxed text-lg">
                Tenho conhecimento sólido em Java e Spring Boot, além de experiência com ferramentas 
                essenciais como Postman, Docker e GitHub. Estou sempre em busca de novos desafios e 
                oportunidades de aprendizado para crescer profissionalmente e entregar valor aos projetos.
              </p>
            </div>
            
            <div className="grid grid-cols-3 gap-6">
              <div className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <div className="text-3xl font-bold text-purple-400 mb-2">9+</div>
                <div className="text-gray-300">Tecnologias</div>
              </div>
              <div className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <div className="text-3xl font-bold text-purple-400 mb-2">10+</div>
                <div className="text-gray-300">Projetos</div>
              </div>
              <div className="text-center bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <div className="text-3xl font-bold text-purple-400 mb-2">100%</div>
                <div className="text-gray-300">Dedicação</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">Habilidades e Conhecimentos</h2>
            <p className="text-xl text-gray-300">Tecnologias que domino</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: 'Java',
                description: 'Linguagem principal para desenvolvimento back-end',
                icon: '☕',
                category: 'backend'
              },
              {
                name: 'Spring Boot',
                description: 'Framework para desenvolvimento de APIs REST',
                icon: '🍃',
                category: 'backend'
              },
              {
                name: 'Python',
                description: 'Linguagem versátil para desenvolvimento e automação',
                icon: '🐍',
                category: 'backend'
              },
              {
                name: 'Django',
                description: 'Framework web Python para desenvolvimento rápido',
                icon: '🎯',
                category: 'backend'
              },
              {
                name: 'PostgreSQL',
                description: 'Sistema de gerenciamento de banco de dados relacional',
                icon: '🐘',
                category: 'database'
              },
              {
                name: 'MongoDB',
                description: 'Banco de dados NoSQL orientado a documentos',
                icon: '🍃',
                category: 'database'
              },
              {
                name: 'Postman',
                description: 'Ferramenta para testes de APIs',
                icon: '📮',
                category: 'tools'
              },
              {
                name: 'Docker',
                description: 'Containerização de aplicações',
                icon: '🐳',
                category: 'tools'
              },
              {
                name: 'GitHub',
                description: 'Controle de versão e colaboração',
                icon: '🐙',
                category: 'tools'
              },
              {
                name: 'Git',
                description: 'Sistema de controle de versão distribuído',
                icon: '📝',
                category: 'tools'
              }
            ].map((skill, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 hover:border-purple-400/50 transition-all duration-300 hover:transform hover:scale-105"
              >
                <div className="text-4xl mb-4">{skill.icon}</div>
                <h3 className="text-xl font-bold text-white mb-3">{skill.name}</h3>
                <p className="text-gray-300">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-16 px-6 bg-black/20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">Projetos em Destaque</h2>
            <p className="text-xl text-gray-300">Alguns dos meus trabalhos recentes</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: 'Sistema de Usuários',
                description: 'Sistema completo para gerenciamento de usuários com funcionalidades CRUD',
                tech: ['Java', 'Spring Boot', 'PostgreSQL'],
                image: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=800',
                github: 'https://github.com/RafaelFrancoD/usuario'
              },
              {
                title: 'Conta Bancária - DIO',
                description: 'Projeto de simulação de conta bancária desenvolvido durante curso da DIO',
                tech: ['Java', 'POO', 'Collections'],
                image: 'https://images.pexels.com/photos/259200/pexels-photo-259200.jpeg?auto=compress&cs=tinysrgb&w=800',
                github: 'https://github.com/RafaelFrancoD/Testando-Conta-bancaria-DIO.ME'
              },
              {
                title: 'Aprendendo Spring',
                description: 'Projeto de estudos focado no aprendizado do framework Spring Boot',
                tech: ['Java', 'Spring Boot', 'REST API'],
                image: 'https://images.pexels.com/photos/577585/pexels-photo-577585.jpeg?auto=compress&cs=tinysrgb&w=800',
                github: 'https://github.com/RafaelFrancoD/aprendendo-spring'
              },
              {
                title: 'DIO Lab Open Source',
                description: 'Contribuição para projeto open source da Digital Innovation One',
                tech: ['Git', 'GitHub', 'Open Source'],
                image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
                github: 'https://github.com/digitalinnovationone/dio-lab-open-source'
              },
              {
                title: 'Projeto Escola',
                description: 'Sistema de gerenciamento escolar com funcionalidades administrativas',
                tech: ['Java', 'Spring Boot', 'JPA'],
                image: 'https://images.pexels.com/photos/159844/cellular-education-classroom-159844.jpeg?auto=compress&cs=tinysrgb&w=800',
                github: 'https://github.com/RafaelFrancoD/Projeto-Escola'
              }
            ].map((project, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-lg overflow-hidden border border-white/20 hover:border-purple-400/50 transition-all duration-300 hover:transform hover:scale-105"
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-3">{project.title}</h3>
                  <p className="text-gray-300 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="bg-purple-600/30 text-purple-300 px-3 py-1 rounded-full text-sm"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <a
                      href={project.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors duration-300 hover:scale-105 transform"
                    >
                      <Github size={16} />
                      Ver Projeto
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">Entre em Contato</h2>
            <p className="text-xl text-gray-300">Vamos conversar sobre oportunidades</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 flex items-center gap-4">
                <div className="bg-purple-600 p-3 rounded-full">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">Email</h4>
                  <a href="mailto:rafael.personal83@hotmail.com" className="text-purple-400 hover:text-purple-300 transition-colors">
                    rafael.personal83@hotmail.com
                  </a>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 flex items-center gap-4">
                <div className="bg-blue-600 p-3 rounded-full">
                  <Linkedin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">LinkedIn</h4>
                  <a href="https://www.linkedin.com/in/rafaelfrancoazevedo/" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 transition-colors">
                    linkedin.com/in/rafaelfrancoazevedo
                  </a>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 flex items-center gap-4">
                <div className="bg-gray-800 p-3 rounded-full">
                  <Github className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">GitHub</h4>
                  <a href="https://github.com/RafaelFrancoD" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 transition-colors">
                    github.com/RafaelFrancoD
                  </a>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20 flex items-center gap-4">
                <div className="bg-green-600 p-3 rounded-full">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-white font-semibold mb-1">WhatsApp</h4>
                  <a href="https://wa.me/5517992256180" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:text-purple-300 transition-colors">
                    (17) 99225-6180
                  </a>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <form className="space-y-6">
                <div>
                  <input
                    type="text"
                    placeholder="Seu Nome"
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-400 focus:outline-none transition-colors"
                    required
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Seu Email"
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-400 focus:outline-none transition-colors"
                    required
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Sua Mensagem"
                    rows={5}
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-purple-400 focus:outline-none transition-colors resize-none"
                    required
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/25 transition-all duration-300 transform hover:scale-105"
                >
                  Enviar Mensagem
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 bg-black/40 border-t border-white/10">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-gray-400">
            &copy; 2025 Rafael Américo Franco de Azevedo. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;